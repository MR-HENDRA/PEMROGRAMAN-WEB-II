<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

  <title>Document</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Caveat+Brush&family=Leckerli+One&family=Lilita+One&family=Quicksand:wght@400;700&display=swap');

    body {

      font-family: 'Quicksand', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #ffffff;
      scroll-behavior: smooth;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }

    h1 {
      text-align: center;
      margin-bottom: 30px;
    }

    table {
      border-collapse: collapse;
      width: 100%;
    }

    th,
    td {
      padding: 10px;
      text-align: center;
      border: 1px solid #ddd;
    }

    th {
      background-color: #0002A1;
      color: #fff;
    }

    .btn {
      display: inline-block;
      padding: 10px 20px;
      margin: 230px;
      background-color: #0002A1;
      color: #fff;
      text-decoration: none;
      border-radius: 5px;
      margin-top: 10px;
    }

    .btn:hover {
      background-color: #0044ee;
    }
  </style>

</head>

<body>
  <?php
  include 'koneksi.php';

  $query = mysqli_query($koneksi, "SELECT * FROM tbl_hendrausman");

  ?>

  <table>
    <tr>
      <th>NIDN</th>
      <th>Nama Dosen</th>
      <th>Tanggal Mulai Tugas</th>
      <th>Jenjang Pendidikan</th>
      <th>Bidang Keilmuan</th>
      <th>Aksi</th>
    </tr>

    <?php while ($data = mysqli_fetch_array($query)) { ?>
      <tr>
        <td><?php echo $data['nidn']; ?></td>
        <td><?php echo $data['nama_dosen']; ?></td>
        <td><?php echo $data['tgl_mulai_tugas']; ?></td>
        <td><?php echo $data['jenjang_pendidikan']; ?></td>
        <td><?php echo $data['bidang_keilmuan']; ?></td>
        <td>
          <a href="edit.php?nidn=<?php echo $data['nidn']; ?>">Edit</a>
          <a href="hapus.php?nidn=<?php echo $data['nidn']; ?>">Hapus</a>
        </td>
      </tr>
    <?php } ?>
  </table>
  <div class="container">
    <a href="tambah.php" class="btn">Tambah Data</a>
  </div>
</body>

</html>