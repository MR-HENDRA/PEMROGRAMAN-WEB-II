<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <?php
  include 'koneksi.php';

  $nidn = $_GET['nidn'];

  $query = mysqli_query($koneksi, "SELECT * FROM tbl_hendrausman WHERE nidn ='$nidn'");
  $data = mysqli_fetch_array($query);

  if (isset($_POST['submit'])) {
    $nidn = $_POST['nidn'];
    $dosen = $_POST['nama_dosen'];
    $tugas = $_POST['tgl_mulai_tugas'];
    $pendidikan = $_POST['jenjang_pendidikan'];
    $ilmu = $_POST['bidang_keilmuan'];

    $query = "UPDATE tbl_hendrausman SET nidn='$nidn', nama_dosen='$dosen', tgl_mulai_tugas='$tugas', jenjang_pendidikan='$pendidikan', bidang_keilmuan='$ilmu' WHERE id='$id'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
      header("Location: index.php");
    } else {
      echo "Gagal mengubah data";
    }
  }
  ?>

  <form method="POST">
    <label>NIDN:</label><br>
    <input type="text" name="nidn" value="<?php echo $data['nidn']; ?>"><br>
    <label>Nama Dosen:</label><br>
    <input type="text" name="nama_dosen" value="<?php echo $data['nama_dosen']; ?>"><br>
    <label>Tanggal Mulai Tugas:</label><br>
    <input type="date" name="tgl_mulai_tugas" value="<?php echo $data['tgl_mulai_tugas']; ?>"><br><br>
    <label>Jenjang Pendidikan:</label><br>
    <input type="text" name="jenjang_pendidikan" value="<?php echo $data['jenjang_pendidikan']; ?>"><br><br>
    <label>Bidang Keilmuan:</label><br>
    <input type="text" name="bidang_keilmuan" value="<?php echo $data['bidang_keilmuan']; ?>"><br><br>
    <input type="submit" name="submit" value="Update">
  </form>
</body>

</html>