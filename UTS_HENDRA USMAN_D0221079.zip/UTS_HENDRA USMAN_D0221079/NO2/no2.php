<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>N0 2</title>
</head>

<body>
    <?php

    $harga_phaser = 7500;
    $harga_tricorder = 12500;
    $harga_visor = 16000;
    $harga_analyzer_photonik = 2300;

    $diskon = 0.05;


    $harga_total_sebelum_diskon = ($harga_phaser * 2) + ($harga_tricorder * 5) + ($harga_visor * 1) + ($harga_analyzer_photonik * 3);


    $harga_total_setelah_diskon = $harga_total_sebelum_diskon - ($harga_total_sebelum_diskon * $diskon);


    echo "Daftar Peralatan Pak Ogah: <br>";
    echo "- Senjata phaser: $harga_phaser dolar <br>";
    echo "- Tricorder: $harga_tricorder dolar <br>";
    echo "- Visor: $harga_visor dolar <br>";
    echo "- Analyzer Photonik: $harga_analyzer_photonik dolar <br>";
    echo "<br>";
    echo "Harga total sebelum diskon: $harga_total_sebelum_diskon dolar <br>";
    echo "Diskon langganan 5%: " . ($harga_total_sebelum_diskon - $harga_total_setelah_diskon) . "<br>";
    echo "Harga total setelah diskon: $harga_total_setelah_diskon dolar";
    ?>
</body>

</html>