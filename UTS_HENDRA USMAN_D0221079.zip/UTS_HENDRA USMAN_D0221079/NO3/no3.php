<!DOCTYPE html>
<html>
<head>
	<title>Program Aplikasi Berjualan</title>
</head>
<body>
	<h1>Hitung data penjualan</h1>
	<form method="POST">
		<label>Jumlah Barang:</label>
		<input type="number" name="jumlah_barang" required><br><br>
		<label>Pelanggan:</label>
		<input type="radio" name="pelanggan" value="Ya" required>Ya
		<input type="radio" name="pelanggan" value="Tidak" required>Tidak<br><br>
		<input type="submit" name="submit" value="Hitung">
	</form>

	<?php
		if(isset($_POST['submit'])) {
			$jumlah_barang = $_POST['jumlah_barang'];
			$pelanggan = $_POST['pelanggan'];
			$harga_barang = 1500;

			if($pelanggan == "Ya") {
				$diskon = 0.1;
			} else {
				$diskon = 0;
			}

			$harga_total_sebelum_diskon = $jumlah_barang * $harga_barang;
			$harga_total_setelah_diskon = $harga_total_sebelum_diskon - ($harga_total_sebelum_diskon * $diskon);

			echo "<h2>Ringkasan Pembelian:</h2>";
			echo "Jumlah Barang: $jumlah_barang <br>";
			echo "Pelanggan: $pelanggan <br>";
			echo "Harga Barang: $harga_barang <br>";
			echo "Harga Total Sebelum Diskon: $harga_total_sebelum_diskon <br>";
			echo "Diskon: " . ($diskon * 100) . "% <br>";
			echo "Harga Total Setelah Diskon: $harga_total_setelah_diskon";
		}
	?>
</body>
</html>
