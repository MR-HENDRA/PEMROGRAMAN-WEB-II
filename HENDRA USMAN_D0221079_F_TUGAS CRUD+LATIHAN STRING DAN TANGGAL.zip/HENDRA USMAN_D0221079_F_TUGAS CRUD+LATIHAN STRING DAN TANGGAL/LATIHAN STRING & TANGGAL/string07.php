<?php
$warna = array('merah', 'hijau', 'kuning', 'biru', 'jingga', 'coklat', 'hitam');
$warni = implode(", ", $warna);

echo "Balon-balon itu berwarna " . $warni;
// meraah,hijau,kuning,biru,jingga,coklat,hitam 
?>