<?php
$str = "We will come to you, my HONEY";

echo "<b>String Asli</b>: $str";
echo "<br><b>strtolower()</b>: ". strtolower($str);
echo "<br><b>strtoupper()</b>: ". strtoupper($str);
echo "<br><b>ucfirst()</b>: ". ucfirst($str);
echo "<br><b>ucwords()</b>: ". ucwords($str);
echo "<br><b>strrev()</b>: ". strrev($str);
echo "<br><b>Jumlah karakter</b>: ". strlen($str);
?>