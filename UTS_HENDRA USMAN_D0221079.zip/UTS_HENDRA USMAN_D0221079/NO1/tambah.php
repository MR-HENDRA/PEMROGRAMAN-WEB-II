<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 50px;
      padding: 120px;
      background-color: #0002A1;
      text-align: center;
      color: #fff;
    }
  </style>


</head>

<body>
  <?php
  include 'koneksi.php';

  if (isset($_POST['submit'])) {
    $nidn = $_POST['nidn'];
    $dosen = $_POST['nama_dosen'];
    $tugas = $_POST['tgl_mulai_tugas'];
    $pendidikan = $_POST['jenjang_pendidikan'];
    $ilmu = $_POST['bidang_keilmuan'];

    $query = "INSERT INTO tbl_hendrausman (nidn, nama_dosen, tgl_mulai_tugas, jenjang_pendidikan, bidang_keilmuan) VALUES ('$nidn','$dosen', '$tugas', '$pendidikan', '$ilmu')";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
      header("Location: index.php");
    } else {
      echo "Gagal menambahkan data";
    }
  }
  ?>

  <div>
    <form method="post">
      <label>NIDN:</label><br>
      <input type="text" name="nidn"><br>
      <label>Nama Dosen:</label><br>
      <input type="text" name="nama_dosen"><br>
      <label>Tanggal Mulai Tugas:</label><br>
      <input type="date" name="tgl_mulai_tugas"><br>
      <label>Jenjang Pendidikan:</label><br>
      <select name="jenjang_pendidikan">
        <option value="">Silahkan Pilih</option>
        <option value="s2">S2</option>
        <option value="s3">S3</option>
      </select><br><br>
      <label>Bidang Keilmuan:</label><br>
      <input type="text" name="bidang_keilmuan"><br><br>
      <input type="submit" name="submit" value="Tambahkan">
    </form>

  </div>
</body>

</html>