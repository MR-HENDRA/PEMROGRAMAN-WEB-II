<?php
include 'koneksi.php';

$nidn = $_GET['nidn'];

$query = "DELETE FROM tbl_hendrausman WHERE nidn='$nidn'";
$result = mysqli_query($koneksi, $query);

if ($result) {
  header("Location: index.php");
} else {
  echo "Gagal menghapus data";
}
?>
